package packageTwo;

import packageOne.ProtectedClass;

public class ProtectedSubClass extends ProtectedClass {

}

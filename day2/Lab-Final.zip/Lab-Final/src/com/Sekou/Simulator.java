package com.Sekou;

public class Simulator {
	
	public static void main(String[] args){
		System.out.println("We are working on Final keyword ");
        FinalClass fc = new FinalClass();
        
//        fc.type = "New Value";
//        ClassA classA = new ClassA();
        
//        fc.classA = new ClassA(); 
        
        fc.classA.greeting = "New Greeting";
        
        
        
        
    }

}


public class ThisTest {
	
	
	public static void main(String[] args) {
        //create instance here
        A classA = new A();

        //set the value of id
//        classA.setId(5);

        //print the id value
        System.out.println(classA.getId());
	}

}
